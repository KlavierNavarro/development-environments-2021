package reviews.Main;
import java.util.Arrays;
import reviews.Data.User;
import reviews.Data.Business;
import reviews.Data.Review;
import reviews.Data.Garage;
import reviews.Data.Restaurant;
import reviews.Data.Hairdresser;

public class Management{
    private User[] users;
    private Business[] businesses;

    public void initialize(){
        String login = "login", password = "password";
        String name = "Business ", location = "Location ";
        String food = "Type ";
        float price = 1;
        boolean unisex = true;

        for(int i = 0; i < 10; i++){
            login += i+2;
            password += i+4;
            users[i] = new User(login, password);
        }

        for(int i = 0; i < 2; i++){
            name += i+1;
            location += i+1;
            Review[] reviews = new Review[2];
            reviews[0] = new Review(users[0], "comment", 4);
            reviews[1] = new Review(users[1], "comment", 5);
        }

        for(int i = 2; i < 4; i++){
            name += i+1;
            location += i+1;
            Review[] reviews = new Review[2];
            reviews[0] = new Review(users[0], "comment", 4);
            reviews[1] = new Review(users[4], "comment", 3);
        }

        for(int i = 4; i < 6; i++){
            name += i+1;
            location += i+1;
            Review[] reviews = new Review[2];
            reviews[0] = new Review(users[5], "comment", 5);
            reviews[0] = new Review(users[4], "comment", 5);
        }
    }

    public User login(String username, String password){
        boolean found = false;
        int position = 10;
        for(int i = 0; i < users.length; i++){
            if(users[i].getLogin() == username &&
                users[i].getPassword() == password){
                position = i;
                found = true;
            }
        }
        if(found && position <= 9){
            return users[position];
        }
        else{
            return null;
        }
    }

    public void myReviews(User user){
        for(int i = 0; i < businesses.length; i++){
            for(int j = 0; j < businesses[i].getReviews().length; j++){
                if(businesses[i].getReviews()[j].getUser().getLogin()
                    == user.getLogin()){
                    System.out.println(businesses[i].getReviews()[j].toString());
                }
            }
        }
    }

    public void sortBusinessesByName(){
        Arrays.sort(businesses);
        for(int i = 0; i < businesses.length; i++){
            System.out.println(businesses[i].toString());
        }
    }

    public  void  sortBusinessesByRating(int type){
        Business temp;
            for(int i = 0; i < businesses.length; i++){
            for(int j = 1; j < (businesses.length - i); j++){
                if(businesses[j - 1].reviewAverage() <
                    businesses[j].reviewAverage()){
                        temp = businesses[j - 1];
                        businesses[j - 1] = businesses[j];
                        businesses[j] = temp;
                }
            }
        }

        switch(type){
            case 1:
                for(int i = 0; i < businesses.length; i++){
                    if(businesses[i] instanceof Restaurant){
                        System.out.println(businesses[i].toString());
                    }
                }
                break;
            case 2:
                for(int i = 0; i < businesses.length; i++){
                    if(businesses[i] instanceof Garage){
                        System.out.println(businesses[i].toString());
                    }
                }
                break;
            case 3:
                for(int i = 0; i < businesses.length; i++){
                    if(businesses[i] instanceof Hairdresser){
                        System.out.println(businesses[i].toString());
                    }
                }
                break;
        }
    }

    public  void changeReview(){
        
    }

    public Business findBusiness(String name){
        int position = 0;
        boolean found = false;
        for(int i = 0; i < businesses.length; i++){
            if(businesses[i].getName().equals(name)){
                position = i;
                found = true;
            }
        }
        if(found){
            return businesses[position];
        }
        else{
            return null;
        }
    }

    public Review findReview(User user, Business business){
        int position = 0;
        boolean found = false;
        for(int i = 0; i > business.getReviews().length; i++){
            if(business.getReviews()[i].getUser().equals(user)){
                position = i;
                found = true;
            }
        }
        if(found){
            return business.getReviews()[position];
        }
        else{
            return null;
        }
    }

    public static void changeReview(Review r, String comment, int rating){
        r.setComment(comment);
        r.setRating(rating);
    }
}