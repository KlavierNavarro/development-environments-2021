package reviews.Main;
import java.util.Scanner;
import reviews.Data.Review;
import reviews.Data.User;
import reviews.Data.Business;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Management management = new Management();
        String login, password, name, comment;
        int option, type, rating;
        User user;
        Business business;
        Review review;

        management.initialize();
        System.out.print("Login: ");
        login = sc.nextLine();
        System.out.print("Password: ");
        password = sc.nextLine();
        user = management.login(login, password);

        do{
            System.out.println("Choose an option:");
            System.out.println("1. My reviews");
            System.out.println("2. Business list");
            System.out.println("3. Top rated businesses");
            System.out.println("4. Edit my review");
            System.out.println("5. Quit");
            option = sc.nextInt();

            switch (option) {
                case 1:
                    management.myReviews(user);
                    break;
                case 2:
                    management.sortBusinessesByName();
                    break;
                case 3:
                    System.out.println("Select the number of the businesses " +
                        "you want to see:");
                    System.out.println("1. Restaurants");
                    System.out.println("2. Garages");
                    System.out.println("3. Hairdressers");
                    type = sc.nextInt();
                    management.sortBusinessesByRating(type);
                    break;
                case 4:
                    System.out.println("What's the name of the business you " +
                    "wrote the review for?:");
                    name = sc.next();
                    business = management.findBusiness(name);
                    if(business != null){
                        review = management.findReview(user, business);

                        if(review != null){
                            System.out.println(review.toString());
                            System.out.println("New comment:");
                            comment = sc.next();
                            System.out.println("New rating:");
                            rating = sc.nextInt();
                            Management.changeReview(review, comment, rating);
                        }
                    }
                    break;
                case 5:
                    System.out.println("End of program");
                    break;
            }
        }
        while(option != 5);
    }
}
