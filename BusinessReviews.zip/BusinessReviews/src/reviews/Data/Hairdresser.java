package reviews.Data;

public class Hairdresser extends Business {
    private boolean unisex;

    public Hairdresser(String name, String location, Review[] reviews, boolean unisex) {
        super(name, location, reviews);
        this.unisex = unisex;
    }

    public boolean isUnisex() {
        return this.unisex;
    }

    public boolean getUnisex() {
        return this.unisex;
    }

    public void setUnisex(boolean unisex) {
        this.unisex = unisex;
    }

    @Override
    public String toString() {
        return super.toString() + " - " + unisex;
    }
     
}
