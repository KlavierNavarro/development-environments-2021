package reviews.Data;

public class Restaurant extends Business {
    String foodType;

    public Restaurant(String name, String location, Review[] reviews, String foodType) {
        super(name, location, reviews);
        this.foodType = foodType;
    }

    public String getFoodType() {
        return this.foodType;
    }

    public void setFoodType(String foodType) {
        this.foodType = foodType;
    }

    @Override
    public String toString() {
        return super.toString() + " - " + getFoodType();
    }

}
