package reviews.Data;

public abstract class Business implements Comparable<Business> {
    protected String name;
    protected String location;
    protected Review[] reviews;

    public Business(String name, String location, Review[] reviews) {
        this.name = name;
        this.location = location;
        this.reviews = reviews;
    }

    public int reviewAverage(){
        int reviewAverage = 0;

        for(Review r : this.reviews){
            reviewAverage += r.getRating();
        }
        reviewAverage /= reviews.length;

        return reviewAverage;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return this.location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Review[] getReviews() {
        return this.reviews;
    }

    @Override
    public String toString() {
        return getName() + "(" + getLocation() + ")\n" + "Review average: " +
            reviewAverage();
    }

    @Override
    public int compareTo(Business o) {
        return name.compareTo(o.name);
    }
}
